package tests;

import java.util.ArrayList;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;
import org.testng.annotations.Test;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.AfterTest;

import pageObjects.SearchPage;
import pageObjects.SearchResultPage;
import pageObjects.TranslatorPage;

public class GoogleTranslatorTest {

	WebDriver driver;
	private SearchPage searchPage;
	private SearchResultPage searchResultPage;
	private TranslatorPage translatorPage;
	private String searchCriteria = "google translate";
	private String textToTranslate = "luxoft test task";
	private String languageToTranslate = "Polish";
	private String assertionText = "zadaniem testu";

	@BeforeTest
	public void beforeTest() {
		driver = new FirefoxDriver();

		// POM for https://google.com
		searchPage = PageFactory.initElements(driver, SearchPage.class);
		// POM for search result page
		searchResultPage = PageFactory.initElements(driver,
				SearchResultPage.class);
		// POM for Google translator page
		translatorPage = PageFactory.initElements(driver, TranslatorPage.class);

		searchPage.open("http://www.google.com/");
	}

	@Test
	public void test() {

		// Search with criteria
		searchPage.search(searchCriteria);
		// Open Google translator page
		searchResultPage.openSearchResult();
		// Translate text to Polish
		translatorPage.addText(textToTranslate);
		translatorPage.selectLanguage(languageToTranslate);

		Assert.assertTrue(translatorPage.translate().contains(assertionText));
	}

	@AfterTest
	public void afterTest() {
		// Close Translator windows
		driver.close();
		// Switch to main window and close it
		ArrayList<String> mainWindow = new ArrayList<String>(
				driver.getWindowHandles());
		driver.switchTo().window(mainWindow.get(0));
		driver.close();

		try {
			Thread.sleep(5000);
			driver.quit();
		} catch (Exception e) {
		}

	}

}
