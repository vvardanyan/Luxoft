package pageObjects;

import java.util.Set;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.interactions.Actions;

/**
 * Page Object for search result page
 */
public class SearchResultPage {
	protected WebDriver driver;

	public SearchResultPage(WebDriver driver) {
		this.driver = driver;
	}

	public void openSearchResult() {

		WebElement link = driver.findElement(By
				.xpath("//a[contains(@href, 'translate.google.com')]"));

		// Open link in new window
		Actions newWindow = new Actions(driver);
		newWindow.keyDown(Keys.SHIFT).click(link).keyUp(Keys.SHIFT).build()
				.perform();
		try {
			Thread.sleep(5000);
			// Handle windows change
			String base = driver.getWindowHandle();
			Set<String> set = driver.getWindowHandles();

			// remove base window
			set.remove(base);
			assert set.size() == 1;
			driver.switchTo().window((String) set.toArray()[0]);

		} catch (InterruptedException e) {
			e.printStackTrace();
		}

	}

}
