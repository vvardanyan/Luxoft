package pageObjects;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 *Page Object for Google translator page 
 */
public class TranslatorPage{

	protected WebDriver driver;

	@FindBy(xpath = "//*[@id='source']")
	private WebElement translatorInputField;
	@FindBy(id = "gt-tl-gms")
	private WebElement languageSelector;
	@FindBy(xpath = "//*[contains(text(), 'Polish')]")
	private WebElement languageToTranslate;
	@FindBy(id = "gt-submit")
	private WebElement translateButton;

	public TranslatorPage(WebDriver driver) {
		this.driver = driver;
	}

	public void addText(String textToTranslate) {
		translatorInputField.sendKeys(textToTranslate);
	}

	public void selectLanguage(String language) {
		languageSelector.click();
		languageToTranslate.click();

	}

	public String translate() {
		translateButton.click();
		String translatedText = "";

		List<WebElement> spans = driver.findElements(By
				.xpath("//*[@id='result_box']"));
		for (WebElement span : spans) {

			translatedText += span.getText() + " ";
		}
		return translatedText.toLowerCase();
	}

	
}
