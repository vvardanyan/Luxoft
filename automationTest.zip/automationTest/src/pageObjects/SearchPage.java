package pageObjects;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;

/**
 *Page Object for Google search page 
 */
public class SearchPage {
	
	protected WebDriver driver;
	
	@FindBy(name="q")
	private WebElement searchInputField;
	@FindBy(name="btnK")
	private WebElement searchButton;

	
	public SearchPage(WebDriver driver) {
		this.driver = driver;
		}
	
	public void open(String url) {
		driver.get(url);
		}
		
	public void search(String searchCritaria){
		
		searchInputField.sendKeys(searchCritaria);
		searchButton.click();
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}
	    
	

}
